<?php
  session_start();
  // require 'session.php';
  include 'navbar.php';
  require 'model/db.php';
  
  // if user is registered
  if (!isset($_SESSION['reg_user'])) {
    header("Location: register.php");
  }

  $msg = $msgClass = '';

  if(filter_has_var(INPUT_POST, 'submit')){
  	$code = mysqli_real_escape_string($conn, $_POST['code']);
  	$user_id = $_SESSION['reg_user'];

  	$query = $conn->query("SELECT code FROM student WHERE student_id='$user_id'");
  	$row = $query->fetch_array();
  	$db_code = $row['code'];

  	if(!empty($code)){
       
  		if($code==$db_code){
          header("Location: login.php");
          $update = $conn->query("UPDATE student SET verified='yes' WHERE student_id='$user_id'");
          $_SESSION['verified']='Account verified successfully';
  		}else{
  			// failed
	      $msg = "Enter valid code";
	      $msgClass = "red";
  		}

  	}else{
  		// failed
      $msg = "Please fill in verification code";
      $msgClass = "red";
  	}
  }
?>
<div class="container">
  <div class="box">
    <div class="row">
      <div class="col s12 m12">
        
        <?php if($msg != ''): ?>
          <div id="msgBox" class="card-panel <?php echo $msgClass; ?>">
            <span class="white-text"><?php echo $msg; ?></span>
          </div>
        <?php endif ?>
        <div class="card">
          <div class="card-content">
            <span class="card-title center-align">Email verification code</span>
            <div class="row">
              <form class="col s12" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" novalidate>
             
              <div class="row">
                  <div class="input-field">
                    <i class="material-icons prefix">face</i>
                    <input type="text" id="code" name="code" value="">
                    <label for="name">Enter your code</label>
                  </div>
                </div>

                <div class="row">
                  <p class="center-align">
                    <button type="submit" class="waves-effect waves-light btn blue" name="submit">Submit</button>
                  </p>
                </div>

              </form>
             </div>
         </div>
       </div>

      	</div>
      </div>
  </div>
</div>

<?php
  mysqli_close($conn);
  include 'footer.php';
?>